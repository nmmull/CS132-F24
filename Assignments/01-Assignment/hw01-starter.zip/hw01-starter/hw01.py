from sympy import *

def leading_entry_index(a):
    # TODO
    return None

def is_echelon(a):
    # TODO
    return False

def is_rref(a):
    # TODO
    return False
