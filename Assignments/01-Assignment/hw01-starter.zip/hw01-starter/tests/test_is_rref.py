import unittest
from sympy import *
from gradescope_utils.autograder_utils.decorators import weight, number, visibility
from hw01 import is_rref

class TestIsRREF(unittest.TestCase):

    @weight(1)
    @visibility("after_due_date")
    def test_basic_true(self):
        """simple is_rref true case"""
        a = Matrix([
            [0, 1, 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ])
        self.assertTrue(is_rref(a))

    @weight(1)
    @visibility("after_due_date")
    def test_basic_false(self):
        """simple is_rref false test"""
        a = Matrix([
            [1, 0, 1, 1],
            [0, 0, 1, 1],
            [0, 0, 0, 0]
        ])
        self.assertFalse(is_rref(a))

    @weight(1)
    @visibility("after_due_date")
    def test_zeros_false(self):
        """is_rref test with all-zeros row not at the end"""
        a = Matrix([
            [0, 1, 1, 1],
            [0, 0, 0, 0],
            [0, 0, 1, 1],
            [0, 0, 0, 1]
        ])
        self.assertFalse(is_rref(a))

    @weight(1)
    @visibility("after_due_date")
    def test_all_zeros(self):
        """is_rref on zero matrix"""
        self.assertTrue(is_rref(zeros(50, 100)))

    @weight(1)
    @visibility("after_due_date")
    def test_echelon_single(self):
        """larger is_rref test"""
        a = Matrix([
            [0, 0, 1, 0, 23, 0, 234, 23],
            [0, 0, 0, 1, 1, 0, -23, -11],
            [0, 0, 0, 0, 0, 1, 1, 233],
            [0, 0, 0, 0, 0, 0, 0, 0],
        ])
        self.assertTrue(is_rref(a))
