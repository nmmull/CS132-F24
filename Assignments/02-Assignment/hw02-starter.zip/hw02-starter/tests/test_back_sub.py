import unittest
from sympy import *
from gradescope_utils.autograder_utils.decorators import weight, number, visibility
from hw02 import back_sub

class TestBackSub(unittest.TestCase):

    @weight(1)
    @visibility("after_due_date")
    def test_basic_1(self):
        """basic back_sub tests"""
        a = Matrix([
            [0, 1, 1, 1],
            [0, 0, 1, 1],
            [0, 0, 0, 1],
            [0, 0, 0, 0]
        ])
        out = Matrix([
            [0, 1, 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1],
            [0, 0, 0, 0]
        ])
        back_sub(a)
        self.assertEqual(a, out)

    @weight(1)
    @visibility("after_due_date")
    def test_basic_2(self):
        """basic back_sub test (2)"""
        a = Matrix([
            [1, 0, 0, 1],
            [0, 0, 1, 1],
            [0, 0, 0, 0]
        ])
        out = Matrix([
            [1, 0, 0, 1],
            [0, 0, 1, 1],
            [0, 0, 0, 0]
        ])
        back_sub(a)
        self.assertEqual(a, out)

    @weight(2)
    @visibility("after_due_date")
    def test_back_sub_1(self):
        """larger back_sub test"""
        a = Matrix([
            [0, 0, -2, 134, 1, 52, 234, 23],
            [0, 0, 0, 1, 1, 55, -23, -11],
            [0, 0, 0, 0, 0, 4, 23, 233],
            [0, 0, 0, 0, 0, 0, 0, -248],
        ])
        back_sub(a)
        self.assertEqual(a, a.rref()[0])

    @weight(2)
    @visibility("after_due_date")
    def test_back_sub_2(self):
        """larger back_sub test (2)"""
        a = Matrix([
            [1, 3, 33, 23, 1, -24],
            [0, 0, 1, -4, 3, -1],
            [0, 0, 0, 0, 0, 1],
            [0, 0, 0, 0, 0, 0]
        ])
        back_sub(a)
        self.assertEqual(a, a.rref()[0])

    @weight(2)
    @visibility("after_due_date")
    def test_diag(self):
        """check back_sub on triangular matrix"""
        a = ones(50).upper_triangular(0)
        back_sub(a)
        self.assertEqual(a, eye(50))
