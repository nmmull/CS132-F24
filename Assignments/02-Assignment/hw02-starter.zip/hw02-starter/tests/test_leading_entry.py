import unittest
from sympy import *
from hw02 import leading_entry_index

class TestLeading(unittest.TestCase):

    def test_basic_0(self):
        """simple leading_entry_index test"""
        a = Matrix([
            [0, 1, 1, 1]
        ])
        self.assertEqual(leading_entry_index(a), 1)

    def test_zeros_false(self):
        """all-zeros leading_entry_index test"""
        a = Matrix([
            [0, 0, 0, 0]
        ])
        self.assertEqual(leading_entry_index(a), None)
