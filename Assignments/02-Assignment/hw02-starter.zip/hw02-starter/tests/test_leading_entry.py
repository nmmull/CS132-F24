import unittest
from sympy import *
from gradescope_utils.autograder_utils.decorators import weight, visibility
from hw02 import leading_entry_index

class TestLeading(unittest.TestCase):

    @weight(1)
    @visibility("after_due_date")
    def test_basic_0(self):
        """simple leading_entry_index test"""
        a = Matrix([
            [0, 1, 1, 1]
        ])
        self.assertEqual(leading_entry_index(a), 1)

    @weight(1)
    @visibility("after_due_date")
    def test_zeros_false(self):
        """all-zeros leading_entry_index test"""
        a = Matrix([
            [0, 0, 0, 0]
        ])
        self.assertEqual(leading_entry_index(a), None)
