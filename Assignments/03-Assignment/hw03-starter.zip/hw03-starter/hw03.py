from matlib import *

def vec_scale(val, vec):
    # TODO
    return Vector([], 0)

def vec_add(v1, v2):
    # TODO
    return Vector([], 0)

def vec_inner(v1, v2):
    # TODO
    return 0.0

def mat_vec_mul(a, v):
    # TODO
    return Vector([], 0)
