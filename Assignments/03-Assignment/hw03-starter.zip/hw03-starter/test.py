import unittest
import random
from numpy import isclose
from matlib import *
from hw03 import *

random.seed(5123)

class TestHomework3(unittest.TestCase):

    # vec_scale tests

    def test_vec_scale_basic_1(self):
        """basic vec_scale test 1"""
        v = Vector([1.,2.,3.], 3)
        out = Vector([-1., -2., -3.], 3)
        self.assertTrue(out.equals(vec_scale(-1., v)))

    def test_vec_scale_basic_2(self):
        """basic vec_scale test 2"""
        v = Vector([1., 1., 1., 1., 1., 1., 1., 1.], 8)
        out = Vector([.23, .23, .23, .23, .23, .23, .23, .23], 8)
        self.assertTrue(out.equals(vec_scale(0.23, v)))

    def test_vec_scale_basic_3(self):
        """vec_scale on zeros"""
        v = Vector([0. for _ in range(100)], 100)
        self.assertTrue(v.equals(vec_scale(0.88, v)))

    # vec_add tests

    def test_vec_add_basic_1(self):
        """basic vec_add test 1"""
        v1 = Vector([1.,2.,3.], 3)
        v2 = Vector([4.,5.,6.], 3)
        out = Vector([5., 7., 9.], 3)
        self.assertTrue(out.equals(vec_add(v1, v2)))

    def test_vec_add_basic_2(self):
        """basic vec_add test 2"""
        v1 = Vector([1.,1.,1.,1.,1.,1.], 6)
        v2 = Vector([2.,2.,2.,2.,2.,2.], 6)
        out = Vector([3.,3.,3.,3.,3.,3.], 6)
        self.assertTrue(out.equals(vec_add(v1, v2)))

    def test_vec_add_basic_3(self):
        """vec_add zero on right"""
        v1 = Vector([random.random() for _ in range(100)], 100)
        v2 = Vector([0.0 for _ in range(100)], 100)
        self.assertTrue(v1.equals(vec_add(v1, v2)))

    def test_vec_add_exception(self):
        """vec_add exception"""
        v1 = Vector([1., 2.], 2)
        v2 = Vector([1., 2., 3.], 3)
        with self.assertRaises(Exception) as context:
            vec_add(v1, v2)
        self.assertTrue('DIMENSION MISMATCH' in str(context.exception))

    # vec_inner tests

    def test_vec_inner_basic_1(self):
        """basic vec_inner test 1"""
        v = Vector([1.,2.,3.], 3)
        self.assertTrue(isclose(vec_inner(v, v), 14.))

    def test_vec_inner_basic_2(self):
        """basic vec_inner test 2"""
        v1 = Vector([1.,1.,1.,1.,1.,1.], 6)
        v2 = Vector([2.,2.,2.,2.,2.,2.], 6)
        self.assertTrue(isclose(vec_inner(v1, v2), 12.))

    def test_vec_inner_basic_3(self):
        """vec_inner zero on left"""
        v1 = Vector([random.random() for _ in range(100)], 100)
        v2 = Vector([0.0 for _ in range(100)], 100)
        self.assertTrue(isclose(vec_inner(v1, v2), 0.0))

    def test_vec_inner_exception(self):
        """vec_inner exception"""
        v1 = Vector([1., 2.], 2)
        v2 = Vector([1., 2., 3.], 3)
        with self.assertRaises(Exception) as context:
            vec_inner(v1, v2)
        self.assertTrue('DIMENSION MISMATCH' in str(context.exception))

    # mat_vec_mul test

    def test_mat_vec_mul_basic_1(self):
        """basic mat_vec_mul test 1"""
        a = Matrix([
            [1.,2.,3.],
            [4.,5.,6.],
            [7.,8.,9.]
        ], 3, 3)
        v = Vector([1.,2.,3.], 3)
        w = Vector([14., 32., 50.], 3)
        self.assertTrue(mat_vec_mul(a, v).equals(w))

    def test_mat_vec_mul_basic_2(self):
        """basic mat_vec_mul test 2"""
        a = Matrix([
            [1.,1.,1.,1.],
            [1.,1.,1.,1.],
            [1.,1.,1.,1.],
            [1.,1.,1.,1.],
            [1.,1.,1.,1.]
        ], 5, 4)
        v = Vector([1.,2.,3.,4.], 4)
        w = Vector([10.,10.,10.,10.,10.], 5)
        self.assertTrue(mat_vec_mul(a, v).equals(w))

    def test_mat_vec_mul_basic_3(self):
        """mat_vec_mul on zeros"""
        a = Matrix([[random.random() for _ in range(40)] for _ in range(100)], 100, 40)
        zero40 = Vector([0.0 for _ in range(40)], 40)
        zero100 = Vector([0.0 for _ in range(100)], 100)
        self.assertTrue(zero100.equals(mat_vec_mul(a, zero40)))

    def test_mat_vec_mul_exception(self):
        """mat_vec_mul exception"""
        a = Matrix([[1., 2.], [1., 2.], [1., 2.]], 3, 2)
        v = Vector([1., 2., 3.], 3)
        with self.assertRaises(Exception) as context:
            mat_vec_mul(a, v)
        self.assertTrue('DIMENSION MISMATCH' in str(context.exception))
