import numpy as np
from scipy.linalg import lu

def fwd_elim(a):
    """forward elimination step from Gaussian elimination"""
    # DON'T WORRY ABOUT THIS IMPLEMENTATION
    return lu(a)[2]

def is_con_aug(a):
    """checks if an augmented matrix is consistent

    parameters:

    A: 2D numpy array representing an augmented matrix

    returns:

    True if A represents the augmented matrix of a consistent system
    of linear equations, and False otherwise.

    """
    # TODO
    return False

def np_array_to_col(v):
    """Converts a 1D numpy array to a 2D column

    This will be useful for the latter functions...

    """
    return np.atleast_2d(v).T

def is_con_mat_eq(a, b):
    """checks if a matrix equation is consistent

    parameters:

    A: 2D numpy array
    b: 1D numpy array

    returns:

    True if Ax = b is consistent, and False otherwise.

    """
    # TODO
    return False

def in_span(v, a):
    """checks if a vector is in the span of a list of vectors

    parameters:

    u: 1D numpy array
    A: 2D numpy array

    returns:

    True if u lies in the span of the columns of A.

    """
    # TODO
    return False

def num_pivots(a):
    """returns the number of pivot positions in a matrix

    parameters:

    A: 2D numpy array

    returns:

    the number of pivot positions of A

    NOTE: The matrix A does NOT need to be in echelon form to have
    pivots.  The pivot positions of a matrix are the positions in a
    ROW EQUIVALENT echelon form.

    """
    # TODO
    return False

def full_span(a):
    """checks if the columns of a matrix have full span

    parameters:

    A: 2D numpy array

    returns:

    True if the columns of A span all of Rn, given that A has n rows,
    and False otherwise

    """
    # TODO
    return False

def lin_ind(a):
    """checks if the columns of a matrix are linearly independent

    parameters:

    A: 2D numpy array

    returns:

    True if the columns of A are linearly independent, and False
    otherwise

    """
    # TODO
    return False
