import unittest
import numpy as np
from hw04 import *

X = np.array(
    [[1., 0, 0, 3],
     [0, 1, 0, 2],
     [0, 0, 1, -3]])
X[0] += 2 * X[1] - 3 * X[2]
X[1] += X[0] + X[2]
X[2] += -3 * X[1] + 2 * X[0]
b = X.T[-1]
a = X.T[:-1].T

Y = np.array(
    [[1., 0, 0, 1],
     [0, 1, 0, 2],
     [0, 0, 0, 3]])
Y[0] += 2 * Y[1] + 3 * Y[2]
Y[1] -= 3 * Y[0] + 5 * Y[2]
Y[2] += Y[0] + Y[1]
d = Y.T[-1]
c = Y.T[:-1].T

class TestIsConsistent(unittest.TestCase):

    def test_consistent_mat_true(self):
        """Check consistent matrix equation"""
        self.assertTrue(is_con_mat_eq(a, b))

    def test_consistent_mat_false(self):
        """Check inconsistent matrix equation"""
        self.assertFalse(is_con_mat_eq(c, d))

    def test_num_of_pivots(self):
        self.assertEqual(num_pivots(a), 3)

    def test_full_span_true(self):
        """Check full span vectors"""
        self.assertTrue(full_span(a))

    def test_full_span_false(self):
        """Check not full span vectors"""
        self.assertFalse(full_span(c))
