import networkx as nx
import numpy as np
from hw06 import *

# graph for the costar network
G = nx.read_edgelist('costar-network.edgelist.gz', \
                     delimiter='|', \
                     data=[('film', str)])

# a list of the actors where column i of G lists the costars of
# the actor at actor[i]
actors = list(G)

# adjacency matrix of G
adj_mat = nx.to_numpy_array(G)

try:
    with open('seven_steps.nparray') as f:
        print("Trying to load seven steps matrix...")
        seven_steps = np.loadtxt(f)
        print("Loaded seven steps matrix.")
        print("IMPORTANT: Delete \'seven_steps.nparray\' if you want to recompute the matrix.")
except:
    print("Failed to load seven step matrix.")
    print("Computing seven step matrix...")
    seven_steps = at_least_k_steps_matrix(adj_mat, 7)
    np.savetxt('seven_steps.nparray', seven_steps)

# TODO: figure out who's disconnected from everyone else in seven steps
